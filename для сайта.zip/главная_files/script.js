(function (){

    if (typeof BX === 'undefined' || typeof BX.ajax === 'undefined' || window.ymecInited) {
        return;
    }

    window.ymecInited = true;

    let hasActiveRequest = false;


    BX.ready(function(){
        requestEcommerceActions(true);

        if (typeof jQuery === 'function') {
            jQuery(document).on('ajaxSuccess', function(r){
                if (hasActions()) {
                    requestEcommerceActions();
                }
            });
        }



        BX.addCustomEvent('onAjaxSuccess', function(oResponse, r2, r3){
            //if (typeof oResponse !== 'undefined' && oResponse && !oResponse.ecActions && oResponse.status !== 'error') {
                if (hasActions()) {
                    requestEcommerceActions();
                }
            //}
        });

        document.addEventListener("DOMContentLoaded", function() {
            if (typeof jQuery === 'function') {
                jQuery(document).on('shown.bs.modal', function (e) {
                    let form = e.target.querySelector('form');

                    if ((form !== undefined) && (form !== null)) {
                        let counters = window.counters;
                        for (var key in counters) {
                            ym(counters[key], 'reachGoal', 'ym-open-leadform');
                        }
                    }
                });
            }

            if (typeof $.magnificPopup === "object") {
                $.magnificPopup.instance.open = function (data) {
                    $.magnificPopup.proto.open.call(this, data);

                    let form = $.magnificPopup.instance.wrap[0].querySelector('form');
                    if ((form !== undefined) && (form !== null)) {
                        let counters = window.counters;
                        for (var key in counters) {
                            ym(counters[key], 'reachGoal', 'ym-open-leadform');
                        }
                    }
                };
            }

            if (typeof $.fancybox === 'object') {
                $.fancybox.defaults.afterShow = function (fancy) {
                    let form = fancy.$refs.container[0].querySelector('form');

                    if ((form !== undefined) && (form !== null)) {
                        let counters = window.counters;
                        for (var key in counters) {
                            ym(counters[key], 'reachGoal', 'ym-open-leadform');
                        }
                    }
                };
            }

            if (typeof Fancybox === 'function') {
                Fancybox.bind('[data-fancybox]', {
                        on: {
                            done: (fancybox, slide) => {
                                let form = slide.$content.querySelector('form');

                                if ((form !== undefined) && (form !== null)) {
                                    let counters = window.counters;
                                    for (var key in counters) {
                                        ym(counters[key], 'reachGoal', 'ym-open-leadform');
                                    }
                                }
                            }
                        }
                    }
                );
            };

        });
    });

    function requestEcommerceActions(processInstant){
        if (hasActiveRequest) {
            return;
        }

        hasActiveRequest = true;
        BX.ajax.runAction('yandex:metrika.yandex_metrika.Ajax.getEcommerceActions')
            .then(function(oResponse) {
                if (oResponse.status === 'success') {
                    if (typeof oResponse.data.actions !== 'undefined') {
                        const actions = oResponse.data.actions;
                        const actionsIds = Object.keys(actions);
                        if (processInstant) {
                            processActions(actions);
                            removeSentActions(actionsIds);
                            hasActiveRequest = false;
                        } else {
                            setTimeout(function () {
                                processActions(actions);
                                removeSentActions(actionsIds);
                                hasActiveRequest = false;
                            }, 2000);
                        }
                    }
                }

                oResponse.ecActions = true;
                return oResponse;
            }, function (oResponse) {
                oResponse.ecActions = true;
                hasActiveRequest = false;
                return oResponse;
            });
    }

    function processActions(actions){
        let formSended = false;

        for (let id in actions) {

            let action = actions[id];
            if(Object.hasOwn(action, 'ecommerce'))
                window.dataLayer.push(action);
            else {
                if(formSended == false) {
                    let counters = window.counters;
                    for (var key in counters) {
                        ym(counters[key], 'reachGoal', actions[id][0]);
                    }
                    formSended = true;
                }
            }
        }
    }

    function removeSentActions(actionsIds){
        BX.ajax.runAction('yandex:metrika.yandex_metrika.Ajax.removeEcommerceActions', {
            data: {
                'actionsIds': actionsIds
            }
        })
            .then(function(oResponse) {
                oResponse.ecActions = true;
                return oResponse;
            }, function (oResponse) {
                oResponse.ecActions = true;
                return oResponse;
            });

        BX.setCookie('ym_has_actions', '', {
            expires: -1000,
            path: '/'
        });
    }

    function addAction(type){
        BX.ajax.runAction('yandex:metrika.yandex_metrika.Ajax.addEcommerceActions', {
            data: {
                'type': type
            }
        })
            .then(function(oResponse) {
                oResponse.ecActions = true;
                return oResponse;
            }, function (oResponse) {
                oResponse.ecActions = true;
                return oResponse;
            });
    }

    function hasActions(){
        return BX.getCookie('ym_has_actions');
    }

})();